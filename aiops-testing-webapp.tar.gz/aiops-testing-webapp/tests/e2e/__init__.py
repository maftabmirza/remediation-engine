"""
End-to-end tests for AIOps platform
"""
