"""
Safety mechanism tests
"""
