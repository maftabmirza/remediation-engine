"""
Test Management WebApp for AIOps Remediation Engine
"""

__version__ = "1.0.0"
